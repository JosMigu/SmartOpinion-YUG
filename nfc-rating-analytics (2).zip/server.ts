import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { initializeApp as initializeClientApp } from "firebase/app";
import { getFirestore as getClientFirestore, collection, doc, setDoc, getDoc, getDocs, query, where, limit, updateDoc, deleteDoc } from "firebase/firestore";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: undefined,
      email: undefined,
      emailVerified: undefined,
      isAnonymous: undefined,
      tenantId: undefined,
      providerInfo: []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function startServer() {
  console.log("Starting server...");
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
  });

  let firebaseConfig: any = null;
  
  // Try loading from environment variables first (ideal for Vercel/Cloud Run)
  if (process.env.FIREBASE_API_KEY) {
    firebaseConfig = {
      apiKey: process.env.FIREBASE_API_KEY,
      authDomain: process.env.FIREBASE_AUTH_DOMAIN,
      projectId: process.env.FIREBASE_PROJECT_ID,
      appId: process.env.FIREBASE_APP_ID,
      firestoreDatabaseId: process.env.FIREBASE_DATABASE_ID
    };
    console.log("Firebase config loaded from environment variables.");
  } else {
    // Fallback to local JSON file
    try {
      const possiblePaths = [
        path.join(process.cwd(), "firebase-applet-config.json"),
        path.join(__dirname, "firebase-applet-config.json"),
        "./firebase-applet-config.json"
      ];
      
      console.log("Searching for firebase-applet-config.json in:", possiblePaths);
      
      for (const configPath of possiblePaths) {
        try {
          if (fs.existsSync(configPath)) {
            const content = fs.readFileSync(configPath, "utf8");
            firebaseConfig = JSON.parse(content);
            console.log("Firebase config loaded from:", configPath);
            break;
          }
        } catch (e) {
          console.error(`Error reading config from ${configPath}:`, e);
        }
      }
    } catch (err) {
      console.error("CRITICAL: Error loading firebase config:", err);
    }
  }

  if (!firebaseConfig) {
    console.warn("WARNING: Firebase configuration not found (neither Env Vars nor JSON file).");
  }

  let db: any = null;
  function getDb() {
    if (!db) {
      if (!firebaseConfig) {
        console.error("No firebaseConfig found in getDb");
        return null;
      }
      try {
        console.log("Initializing Firebase Client SDK on server...");
        const clientApp = initializeClientApp({
          apiKey: firebaseConfig.apiKey,
          authDomain: firebaseConfig.authDomain,
          projectId: firebaseConfig.projectId,
          appId: firebaseConfig.appId
        });
        
        const dbId = firebaseConfig.firestoreDatabaseId;
        if (dbId && dbId !== "(default)") {
          console.log("Using named Firestore database:", dbId);
          db = getClientFirestore(clientApp, dbId);
        } else {
          console.log("Using default Firestore database");
          db = getClientFirestore(clientApp);
        }
        console.log("Firestore Client initialized successfully.");
      } catch (err) {
        console.error("Error initializing Firestore Client:", err);
      }
    }
    return db;
  }

  // API routes
  app.get("/api/test", (req, res) => res.send("Server is alive!"));
  
  app.get("/api/devices", async (req, res) => {
    try {
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      const devicesSnapshot = await getDocs(collection(db, "devices"));
      const ratingsSnapshot = await getDocs(collection(db, "ratings"));
      const ratings = ratingsSnapshot.docs.map(doc => doc.data());
      const devices = devicesSnapshot.docs.map(doc => {
        const d = doc.data();
        const deviceRatings = ratings.filter(r => r.deviceId === d.id);
        const avg = deviceRatings.length > 0 ? deviceRatings.reduce((acc, r) => acc + r.rating, 0) / deviceRatings.length : 0;
        return { ...d, totalVotes: deviceRatings.length, averageRating: avg.toFixed(1) };
      });
      res.json(devices);
    } catch (error) {
      console.error("Failed to fetch devices:", error);
      res.status(500).json({ error: "Failed to fetch devices" });
    }
  });

  app.post("/api/devices", async (req, res) => {
    console.log("POST /api/devices body:", req.body);
    try {
      const { name } = req.body;
      if (!name) return res.status(400).json({ error: "Nombre es requerido" });
      const db = getDb();
      if (!db) {
        console.error("Database not initialized in POST /api/devices");
        return res.status(500).json({ error: "La base de datos no está inicializada. Por favor, revisa la configuración de Firebase." });
      }
      
      const id = Math.random().toString(36).substr(2, 9);
      const newDevice = {
        id,
        name,
        createdAt: Date.now()
      };
      console.log("Saving new device to collection 'devices' with ID:", id);
      try {
        await setDoc(doc(db, "devices", id), newDevice);
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, `devices/${id}`);
      }
      console.log("Device saved successfully");
      res.json(newDevice);
    } catch (error) {
      console.error("Error creating device in Firestore:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Error interno al guardar en la base de datos" });
    }
  });

  app.patch("/api/devices/:id", async (req, res) => {
    try {
      const { name } = req.body;
      if (!name) return res.status(400).json({ error: "Nombre es requerido" });
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      
      try {
        await updateDoc(doc(db, "devices", req.params.id), { name });
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, `devices/${req.params.id}`);
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating device:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to update device" });
    }
  });

  app.delete("/api/devices/:id", async (req, res) => {
    try {
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      
      try {
        await deleteDoc(doc(db, "devices", req.params.id));
        
        // Delete associated ratings
        const ratingsSnapshot = await getDocs(query(collection(db, "ratings"), where("deviceId", "==", req.params.id)));
        const deletePromises = ratingsSnapshot.docs.map(ratingDoc => deleteDoc(ratingDoc.ref));
        await Promise.all(deletePromises);
        
      } catch (e) {
        handleFirestoreError(e, OperationType.DELETE, `devices/${req.params.id}`);
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting device:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to delete device"
      });
    }
  });

  app.get("/api/devices/:id", async (req, res) => {
    try {
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      const deviceDoc = await getDoc(doc(db, "devices", req.params.id));
      if (!deviceDoc.exists()) return res.status(404).json({ error: "Device not found" });
      const device = deviceDoc.data();
      const ratingsSnapshot = await getDocs(query(collection(db, "ratings"), where("deviceId", "==", req.params.id)));
      const deviceRatings = ratingsSnapshot.docs.map(doc => doc.data()).sort((a, b) => b.timestamp - a.timestamp);
      const avg = deviceRatings.length > 0 ? deviceRatings.reduce((acc, r) => acc + r.rating, 0) / deviceRatings.length : 0;
      res.json({ 
        ...device, 
        totalVotes: deviceRatings.length, 
        averageRating: avg.toFixed(1),
        ratings: deviceRatings 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch device" });
    }
  });

  app.post("/api/rating", async (req, res) => {
    try {
      const { deviceId, rating, metadata, comment, userName } = req.body;
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      const id = Math.random().toString(36).substr(2, 9);
      const newRating = { 
        id, 
        deviceId, 
        rating: Number(rating), 
        timestamp: Date.now(), 
        metadata,
        comment: comment || "",
        userName: userName || "Anónimo"
      };
      try {
        await setDoc(doc(db, "ratings", id), newRating);
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, `ratings/${id}`);
      }
      res.json(newRating);
    } catch (error) {
      console.error("Error saving rating:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to save rating" });
    }
  });

  app.patch("/api/rating/:id", async (req, res) => {
    try {
      const { comment } = req.body;
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      
      try {
        await updateDoc(doc(db, "ratings", req.params.id), { comment });
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, `ratings/${req.params.id}`);
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating rating comment:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Failed to update rating" });
    }
  });

  app.post("/api/track/instagram", async (req, res) => {
    try {
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      
      const analyticsRef = doc(db, "analytics", "instagram_clicks");
      const analyticsDoc = await getDoc(analyticsRef);
      
      let count = 1;
      if (analyticsDoc.exists()) {
        count = (analyticsDoc.data().count || 0) + 1;
      }
      
      await setDoc(analyticsRef, { count, lastClick: Date.now() }, { merge: true });
      res.json({ success: true, count });
    } catch (error) {
      console.error("Error tracking instagram click:", error);
      res.status(500).json({ error: "Failed to track click" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const db = getDb();
      if (!db) return res.status(500).json({ error: "DB not initialized" });
      
      const daysParam = req.query.days ? String(req.query.days) : "7";
      
      const [ratingsSnapshot, devicesSnapshot, analyticsDoc] = await Promise.all([
        getDocs(collection(db, "ratings")),
        getDocs(collection(db, "devices")),
        getDoc(doc(db, "analytics", "instagram_clicks"))
      ]);
      
      const instagramClicks = analyticsDoc.exists() ? (analyticsDoc.data().count || 0) : 0;
      const ratings = ratingsSnapshot.docs
        .map(doc => doc.data())
        .filter(r => r && typeof r.timestamp === 'number' && typeof r.rating === 'number');
      
      const totalVotes = ratings.length;
      const avgRating = totalVotes > 0 ? (ratings.reduce((acc, r) => acc + r.rating, 0) / totalVotes).toFixed(1) : "0.0";
      
      const trend: any[] = [];
      const now = new Date();
      
      if (daysParam === "all") {
        const monthlyData: { [key: string]: { total: number, count: number } } = {};
        ratings.forEach(r => {
          const date = new Date(r.timestamp);
          if (isNaN(date.getTime())) return;
          const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          if (!monthlyData[key]) monthlyData[key] = { total: 0, count: 0 };
          monthlyData[key].total += r.rating;
          monthlyData[key].count += 1;
        });
        
        Object.keys(monthlyData).sort().forEach(key => {
          const [yearStr, monthStr] = key.split('-');
          const year = parseInt(yearStr);
          const month = parseInt(monthStr);
          if (isNaN(year) || isNaN(month)) return;
          
          const dateObj = new Date(year, month - 1);
          const label = dateObj.toLocaleDateString('es-ES', { month: 'short', year: '2-digit' });
          trend.push({
            date: label,
            avgRating: Number((monthlyData[key].total / monthlyData[key].count).toFixed(1)),
            votes: monthlyData[key].count
          });
        });
      } else {
        const days = parseInt(daysParam) || 7;
        for (let i = days - 1; i >= 0; i--) {
          const d = new Date(now);
          d.setDate(d.getDate() - i);
          const dateStr = d.toLocaleDateString('es-ES', { month: 'short', day: 'numeric' });
          const dayStart = new Date(d.setHours(0, 0, 0, 0)).getTime();
          const dayEnd = new Date(d.setHours(23, 59, 59, 999)).getTime();
          
          const dayRatings = ratings.filter(r => r.timestamp >= dayStart && r.timestamp <= dayEnd);
          const dayAvg = dayRatings.length > 0 ? (dayRatings.reduce((acc, r) => acc + r.rating, 0) / dayRatings.length) : 0;
          
          trend.push({
            date: dateStr,
            avgRating: Number(dayAvg.toFixed(1)),
            votes: dayRatings.length
          });
        }
      }

      res.json({ totalVotes, avgRating, activeDevices: devicesSnapshot.size, instagramClicks, trend });
    } catch (error) {
      console.error("CRITICAL ERROR in /api/stats:", error);
      res.status(500).json({ 
        error: "Failed to fetch stats", 
        details: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Catch-all for API routes that are not found
  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // Vite middleware
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting Vite...");
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  return app;
}

const appPromise = startServer().catch(console.error);

export default async (req: any, res: any) => {
  const app = await appPromise;
  if (app) {
    return app(req, res);
  }
  res.status(500).send("Server initialization failed");
};
