export interface Device {
  id: string;
  name: string;
  createdAt: number;
  totalVotes: number;
  averageRating: number;
}

export interface Rating {
  id: string;
  deviceId: string;
  rating: number;
  timestamp: number;
  metadata?: {
    userAgent?: string;
    location?: {
      lat: number;
      lng: number;
    };
  };
}

export interface DeviceStats {
  totalVotes: number;
  averageRating: number;
  ratingDistribution: Record<number, number>;
  trend: {
    date: string;
    avgRating: number;
    votes: number;
  }[];
}
