import React from "react";
import { useSearchParams } from "react-router-dom";
import { Star, CheckCircle2, AlertCircle, Loader2, Instagram, User, MessageSquare } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "@/src/lib/utils";

export default function Rate() {
  const [searchParams] = useSearchParams();
  const deviceId = searchParams.get("device_id");

  const [step, setStep] = React.useState<"rating" | "details" | "success">("rating");
  const [rating, setRating] = React.useState(0);
  const [hoveredRating, setHoveredRating] = React.useState(0);
  const [userName, setUserName] = React.useState("");
  const [comment, setComment] = React.useState("");
  const [status, setStatus] = React.useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = React.useState<string | null>(null);

  const handleRatingSelect = (val: number) => {
    setRating(val);
    setStep("details");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deviceId || rating === 0 || !userName.trim()) return;

    setStatus("loading");
    try {
      const response = await fetch("/api/rating", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deviceId,
          rating,
          userName,
          comment,
          metadata: {
            userAgent: navigator.userAgent,
          },
        }),
      });

      if (!response.ok) throw new Error("Failed to submit rating");
      setStep("success");
    } catch (err) {
      setStatus("error");
      setError("Algo salió mal al enviar tu calificación. Por favor, intenta de nuevo.");
    } finally {
      setStatus("idle");
    }
  };

  if (!deviceId) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 text-center">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-200 p-8">
          <AlertCircle className="w-16 h-16 text-rose-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900">Enlace Inválido</h2>
          <p className="text-slate-600">Este enlace de calificación no es válido o ha expirado.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-200 p-8 text-center overflow-hidden relative">
        <AnimatePresence mode="wait">
          {step === "rating" && (
            <motion.div
              key="rating"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="space-y-8 py-4"
            >
              <div className="space-y-2">
                <h1 className="text-3xl font-black text-slate-900 tracking-tight">¡Tu opinión cuenta!</h1>
                <p className="text-slate-500">¿Cómo fue tu experiencia hoy?</p>
              </div>

              <div className="flex justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onMouseEnter={() => setHoveredRating(star)}
                    onMouseLeave={() => setHoveredRating(0)}
                    onClick={() => handleRatingSelect(star)}
                    className="p-1 transition-transform active:scale-90"
                  >
                    <Star
                      className={cn(
                        "w-12 h-12 transition-colors",
                        star <= (hoveredRating || rating)
                          ? "text-amber-400 fill-current"
                          : "text-slate-200"
                      )}
                    />
                  </button>
                ))}
              </div>
              <p className="text-sm font-bold text-amber-500 uppercase tracking-widest">
                {hoveredRating === 1 && "Muy Malo"}
                {hoveredRating === 2 && "Malo"}
                {hoveredRating === 3 && "Regular"}
                {hoveredRating === 4 && "Bueno"}
                {hoveredRating === 5 && "¡Excelente!"}
                {!hoveredRating && "Selecciona una estrella"}
              </p>
            </motion.div>
          )}

          {step === "details" && (
            <motion.div
              key="details"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-center gap-4 mb-2">
                <button onClick={() => setStep("rating")} className="text-slate-400 hover:text-slate-600">
                  <Star className="w-6 h-6 text-amber-400 fill-current" />
                </button>
                <h2 className="text-2xl font-bold text-slate-900">Casi listo...</h2>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4 text-left">
                <div className="space-y-1">
                  <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Nombre (Obligatorio)
                  </label>
                  <input
                    required
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Tu nombre"
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Comentario (Opcional)
                  </label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Cuéntanos más..."
                    className="w-full h-24 p-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none"
                  />
                </div>

                {error && (
                  <p className="text-rose-600 text-sm font-medium bg-rose-50 p-3 rounded-xl">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={status === "loading" || !userName.trim()}
                  className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {status === "loading" ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    "Enviar Calificación"
                  )}
                </button>
              </form>
            </motion.div>
          )}

          {step === "success" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8 py-6"
            >
              <div className="flex justify-center">
                <div className="bg-emerald-100 p-6 rounded-full">
                  <CheckCircle2 className="w-16 h-16 text-emerald-600" />
                </div>
              </div>
              <div className="space-y-2">
                <h2 className="text-3xl font-black text-slate-900">¡Muchas Gracias!</h2>
                <p className="text-slate-600">Tu opinión nos ayuda a mejorar cada día.</p>
              </div>

              <div className="pt-4 space-y-4">
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Síguenos en Instagram</p>
                <a
                  href="https://www.instagram.com/yug_yogurt"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    fetch("/api/track/instagram", { method: "POST" }).catch(console.error);
                  }}
                  className="inline-flex items-center gap-3 bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:scale-105 transition-transform"
                >
                  <Instagram className="w-6 h-6" />
                  @yug_yogurt
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
