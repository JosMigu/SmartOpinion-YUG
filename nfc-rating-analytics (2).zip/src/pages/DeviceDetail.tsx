import React from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Star, Users, Calendar, ArrowLeft, Tablet, Copy, Check, Edit2, Trash2, X, Loader2, MessageSquare } from "lucide-react";
import StatsCard from "@/src/components/StatsCard";
import RatingChart from "@/src/components/RatingChart";
import { cn } from "@/src/lib/utils";

export default function DeviceDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [device, setDevice] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [copiedId, setCopiedId] = React.useState<number | null>(null);
  
  // Edit state
  const [isEditing, setIsEditing] = React.useState(false);
  const [editName, setEditName] = React.useState("");
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = React.useState(false);

  React.useEffect(() => {
    fetch(`/api/devices/${id}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) throw new Error(data.error);
        setDevice(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [id]);

  const copyToClipboard = (text: string, index: number) => {
    const fullUrl = `${window.location.origin}${text}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedId(index);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRename = async () => {
    if (!editName.trim()) return;
    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/devices/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editName }),
      });
      if (res.ok) {
        setDevice({ ...device, name: editName });
        setIsEditing(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/devices/${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        navigate("/devices");
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="animate-pulse space-y-8"><div className="h-8 bg-slate-200 rounded w-1/4"></div><div className="grid grid-cols-4 gap-6"><div className="h-32 bg-slate-100 rounded"></div><div className="h-32 bg-slate-100 rounded"></div><div className="h-32 bg-slate-100 rounded"></div><div className="h-32 bg-slate-100 rounded"></div></div></div>;

  if (!device) return <div className="text-center py-20"><h2 className="text-2xl font-bold">SmartOpinion no encontrado</h2><Link to="/devices" className="text-indigo-600 mt-4 inline-block">Volver a SmartOpinion</Link></div>;

  const distributionData = [1, 2, 3, 4, 5].map(star => ({
    rating: `${star} Estrella${star > 1 ? 's' : ''}`,
    count: device.ratings ? device.ratings.filter((r: any) => r.rating === star).length : 0
  }));

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/devices" className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </Link>
          <div>
            {isEditing ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="text-2xl font-bold text-slate-900 bg-transparent border-b-2 border-indigo-500 outline-none px-1"
                  autoFocus
                />
                <button
                  onClick={handleRename}
                  disabled={isSubmitting}
                  className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                >
                  {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" />}
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <h2 className="text-2xl font-bold text-slate-900">{device.name}</h2>
            )}
            <p className="text-slate-500">ID del SmartOpinion: {device.id}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!isEditing && (
            <button
              onClick={() => {
                setIsEditing(true);
                setEditName(device.name);
              }}
              className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors font-medium"
            >
              <Edit2 className="w-4 h-4" />
              Renombrar
            </button>
          )}
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors font-medium"
          >
            <Trash2 className="w-4 h-4" />
            Eliminar
          </button>
        </div>
      </div>

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-xl font-bold text-slate-900 mb-2">¿Eliminar SmartOpinion?</h3>
            <p className="text-slate-600 mb-6">
              Esta acción eliminará permanentemente el SmartOpinion y todos sus datos asociados. No se puede deshacer.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 rounded-lg font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 rounded-lg font-semibold bg-rose-600 text-white hover:bg-rose-700 transition-colors"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard title="Votos Totales" value={device.totalVotes} icon={Users} />
        <StatsCard title="Promedio" value={device.averageRating} icon={Star} />
        <StatsCard title="Estado" value="En Línea" icon={Tablet} />
        <StatsCard title="Creado" value="Mar 2026" icon={Calendar} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Distribución de Calificaciones</h3>
          <RatingChart data={distributionData} type="bar" />
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Enlace NFC</h3>
          <div className="space-y-4">
            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
              <div className="flex items-center gap-4">
                <div className="bg-indigo-100 p-3 rounded-xl">
                  <Star className="w-6 h-6 text-indigo-600 fill-current" />
                </div>
                <div>
                  <p className="font-bold text-slate-900">Enlace Único de Calificación</p>
                  <p className="text-sm text-slate-500">Usa este enlace para tu SmartOpinion</p>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-white p-3 rounded-xl border border-slate-200">
                <code className="text-sm text-indigo-600 font-mono flex-1 truncate">
                  /rate?device_id={device.id}
                </code>
                <button
                  onClick={() => copyToClipboard(`/rate?device_id=${device.id}`, 0)}
                  className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-500 flex items-center gap-2"
                >
                  {copiedId === 0 ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-bold text-emerald-600">Copiado</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span className="text-xs font-bold">Copiar</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-2 mb-6">
          <MessageSquare className="w-5 h-5 text-indigo-600" />
          <h3 className="text-lg font-bold text-slate-900">Comentarios Recientes</h3>
        </div>
        <div className="space-y-4">
          {device.ratings && device.ratings.filter((r: any) => r.comment || r.userName).length > 0 ? (
            device.ratings
              .map((r: any) => (
                <div key={r.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={cn(
                              "w-3 h-3",
                              star <= r.rating ? "text-amber-400 fill-current" : "text-slate-200"
                            )}
                          />
                        ))}
                      </div>
                      <span className="font-bold text-slate-900 text-sm">{r.userName || "Anónimo"}</span>
                    </div>
                    <span className="text-xs text-slate-400">
                      {new Date(r.timestamp).toLocaleDateString()} {new Date(r.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  {r.comment && <p className="text-slate-700 text-sm italic">"{r.comment}"</p>}
                </div>
              ))
          ) : (
            <div className="text-center py-12 text-slate-400">
              <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>No hay comentarios todavía.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
