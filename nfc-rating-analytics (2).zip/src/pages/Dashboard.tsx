import React from "react";
import { Users, Star, TrendingUp, Tablet, Instagram } from "lucide-react";
import StatsCard from "@/src/components/StatsCard";
import RatingChart from "@/src/components/RatingChart";
import DeviceComparisonChart from "@/src/components/DeviceComparisonChart";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const [stats, setStats] = React.useState<any>(null);
  const [devices, setDevices] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [timeRange, setTimeRange] = React.useState("7");

  const fetchData = async (days: string) => {
    try {
      const [statsRes, devicesRes] = await Promise.all([
        fetch(`/api/stats?days=${days}`),
        fetch("/api/devices"),
      ]);
      
      if (!statsRes.ok || !devicesRes.ok) {
        const statsErr = !statsRes.ok ? await statsRes.json().catch(() => ({ error: statsRes.statusText })) : null;
        const devicesErr = !devicesRes.ok ? await devicesRes.json().catch(() => ({ error: devicesRes.statusText })) : null;
        
        console.error("API Error Details:", { statsErr, devicesErr });
        throw new Error(statsErr?.details || statsErr?.error || devicesErr?.error || `API returned ${statsRes.status}/${devicesRes.status}`);
      }

      const statsData = await statsRes.json();
      const devicesData = await devicesRes.json();
      setStats(statsData);
      setDevices(Array.isArray(devicesData) ? devicesData : []);
      setError(null);
    } catch (err) {
      console.error("Failed to fetch data", err);
      setError(err instanceof Error ? err.message : "Error desconocido al cargar datos");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchData(timeRange);
  }, [timeRange]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-8 text-center space-y-4">
        <div className="bg-rose-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
          <Star className="w-8 h-8 text-rose-600" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Error al cargar analíticas</h2>
        <p className="text-slate-600 max-w-md mx-auto">{error}</p>
        <button 
          onClick={() => {
            setLoading(true);
            fetchData(timeRange);
          }}
          className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-indigo-700 transition-all"
        >
          Reintentar
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Vista General de Analítica</h2>
          <p className="text-slate-500">Rendimiento en tiempo real de todos los SmartOpinion NFC.</p>
        </div>
        <div className="flex items-center gap-2 text-sm font-medium text-slate-500 bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
          Actualizaciones en Vivo
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <StatsCard
          title="Votos Totales"
          value={stats?.totalVotes || 0}
          icon={Users}
        />
        <StatsCard
          title="Calificación Promedio"
          value={stats?.avgRating || "0.0"}
          icon={Star}
        />
        <StatsCard
          title="SmartOpinion Activos"
          value={stats?.activeDevices || 0}
          icon={Tablet}
        />
        <StatsCard
          title="Clicks Instagram"
          value={stats?.instagramClicks || 0}
          icon={Instagram}
        />
        <StatsCard
          title="Crecimiento"
          value="0%"
          icon={TrendingUp}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-900">Tendencia de Calificaciones</h3>
            <select 
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="text-sm border-slate-200 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="7">Últimos 7 Días</option>
              <option value="30">Últimos 30 Días</option>
              <option value="all">Desde Siempre</option>
            </select>
          </div>
          <RatingChart data={stats?.trend || []} type="area" />
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Mejores SmartOpinion</h3>
          <div className="space-y-4">
            {Array.isArray(devices) && devices.slice(0, 5).map((device) => (
              <Link
                key={device.id}
                to={`/devices/${device.id}`}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors group"
              >
                <div>
                  <p className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {device.name}
                  </p>
                  <p className="text-xs text-slate-500">{device.totalVotes} votos</p>
                </div>
                <div className="flex items-center gap-1 bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md font-bold text-sm">
                  <Star className="w-3 h-3 fill-current" />
                  {device.averageRating}
                </div>
              </Link>
            ))}
          </div>
          <Link
            to="/devices"
            className="block text-center mt-6 text-sm font-semibold text-indigo-600 hover:text-indigo-700"
          >
            Ver Todos los SmartOpinion
          </Link>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-slate-900">Comparativa de SmartOpinion</h3>
          <p className="text-sm text-slate-500">Promedio de estrellas por dispositivo</p>
        </div>
        <DeviceComparisonChart data={devices} />
      </div>
    </div>
  );
}

