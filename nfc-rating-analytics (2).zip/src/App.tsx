/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { BrowserRouter, Routes, Route, Link, useNavigate, Navigate } from "react-router-dom";
import Layout from "@/src/components/Layout";
import Dashboard from "@/src/pages/Dashboard";
import Rate from "@/src/pages/Rate";
import DeviceDetail from "@/src/pages/DeviceDetail";
import Login from "@/src/pages/Login";
import { auth } from "@/src/lib/firebase";
import { onAuthStateChanged, User } from "firebase/auth";
import { Plus, X, Loader2, Edit2, Trash2, Check, Save } from "lucide-react";

// Placeholder for Device List and Detail
const DeviceList = () => {
  const [devices, setDevices] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [isAdding, setIsAdding] = React.useState(false);
  const [newName, setNewName] = React.useState("");
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  
  // Edit state
  const [editingDeviceId, setEditingDeviceId] = React.useState<string | null>(null);
  const [editName, setEditName] = React.useState("");
  const [isEditing, setIsEditing] = React.useState(false);
  const [deletingDeviceId, setDeletingDeviceId] = React.useState<string | null>(null);

  const navigate = useNavigate();

  const fetchDevices = () => {
    setLoading(true);
    fetch("/api/devices")
      .then(res => res.json())
      .then(data => {
        setDevices(Array.isArray(data) ? data : []);
        setLoading(false);
      });
  };

  React.useEffect(() => {
    fetchDevices();
  }, []);

  const handleAddDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    setError(null);
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/devices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName }),
      });
      
      const data = await res.json();
      
      if (res.ok) {
        setNewName("");
        setIsAdding(false);
        fetchDevices();
      } else {
        setError(data.error || "Error al añadir SmartOpinion");
      }
    } catch (err) {
      setError("Error de red al conectar con el servidor");
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRenameDevice = async (id: string) => {
    if (!editName.trim()) return;
    setIsEditing(true);
    try {
      const res = await fetch(`/api/devices/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editName }),
      });
      if (res.ok) {
        setEditingDeviceId(null);
        fetchDevices();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsEditing(false);
    }
  };

  const handleDeleteDevice = async (id: string) => {
    try {
      const res = await fetch(`/api/devices/${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setDeletingDeviceId(null);
        fetchDevices();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading && devices.length === 0) return <div className="animate-pulse space-y-4"><div className="h-8 bg-slate-200 rounded w-1/4"></div><div className="h-64 bg-slate-100 rounded"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900">SmartOpinion</h2>
        <div className="flex items-center gap-3">
          <button
            onClick={fetchDevices}
            className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
            title="Refrescar"
          >
            <Loader2 className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition-colors shadow-sm"
          >
            <Plus className="w-5 h-5" />
            Añadir SmartOpinion
          </button>
        </div>
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-xl border border-indigo-100 shadow-sm animate-in fade-in slide-in-from-top-4 duration-200">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 text-rose-600 rounded-lg text-sm flex items-center gap-2">
              <Plus className="w-4 h-4 rotate-45" />
              {error}
            </div>
          )}
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900">Nuevo SmartOpinion</h3>
            <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
          </div>
          <form onSubmit={handleAddDevice} className="flex gap-3">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Nombre del SmartOpinion (ej. Entrada Principal)"
              className="flex-1 px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              autoFocus
            />
            <button
              type="submit"
              disabled={isSubmitting || !newName.trim()}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              Guardar
            </button>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Nombre</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Votos Totales</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Promedio</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Última Actividad</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {Array.isArray(devices) && devices.map((device) => (
              <tr 
                key={device.id} 
                className="hover:bg-slate-50 transition-colors cursor-pointer group"
                onClick={() => navigate(`/devices/${device.id}`)}
              >
                <td className="px-6 py-4">
                  {editingDeviceId === device.id ? (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="px-2 py-1 border border-indigo-300 rounded focus:ring-2 focus:ring-indigo-500 outline-none w-full"
                        autoFocus
                      />
                      <button
                        onClick={() => handleRenameDevice(device.id)}
                        disabled={isEditing}
                        className="p-1 text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                      >
                        {isEditing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => setEditingDeviceId(null)}
                        className="p-1 text-rose-600 hover:bg-rose-50 rounded transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <span className="font-medium text-slate-900">{device.name}</span>
                  )}
                </td>
                <td className="px-6 py-4 text-slate-600">{device.totalVotes}</td>
                <td className="px-6 py-4">
                  <span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md font-bold text-sm">
                    {device.averageRating}
                  </span>
                </td>
                <td className="px-6 py-4 text-slate-500 text-sm">Activo</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingDeviceId(device.id);
                        setEditName(device.name);
                      }}
                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      title="Renombrar"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeletingDeviceId(device.id);
                      }}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {deletingDeviceId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-xl font-bold text-slate-900 mb-2">¿Eliminar SmartOpinion?</h3>
            <p className="text-slate-600 mb-6">
              Esta acción eliminará permanentemente el SmartOpinion y todos sus datos asociados. No se puede deshacer.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDeletingDeviceId(null)}
                className="px-4 py-2 rounded-lg font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDeleteDevice(deletingDeviceId)}
                className="px-4 py-2 rounded-lg font-semibold bg-rose-600 text-white hover:bg-rose-700 transition-colors"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (!auth) {
      setLoading(false);
      return;
    }
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
        <Route path="/rate" element={<Rate />} />
        <Route
          path="/*"
          element={
            user ? (
              <Layout>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/devices" element={<DeviceList />} />
                  <Route path="/devices/:id" element={<DeviceDetail />} />
                  <Route path="*" element={<Navigate to="/" />} />
                </Routes>
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

