import React from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from "recharts";

interface DeviceComparisonChartProps {
  data: any[];
  height?: number;
}

export default function DeviceComparisonChart({ data, height = 350 }: DeviceComparisonChartProps) {
  // Calculate totals
  const totals = data.reduce((acc, curr) => {
    const votes = Number(curr.totalVotes) || 0;
    const avg = parseFloat(curr.averageRating) || 0;
    return {
      votes: acc.votes + votes,
      points: acc.points + (avg * votes)
    };
  }, { votes: 0, points: 0 });

  const totalAvg = totals.votes > 0 ? (totals.points / totals.votes).toFixed(1) : "0.0";

  // Sort by average rating descending
  const sortedData = [...data].sort((a, b) => parseFloat(b.averageRating) - parseFloat(a.averageRating));

  // Add Total entry
  const chartData = [
    ...sortedData,
    { 
      name: "TOTAL GENERAL", 
      averageRating: totalAvg, 
      totalVotes: totals.votes,
      isTotal: true 
    }
  ];

  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 40 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
          <XAxis
            dataKey="name"
            axisLine={false}
            tickLine={false}
            tick={(props) => {
              const { x, y, payload } = props;
              const isTotal = payload.value === "TOTAL GENERAL";
              return (
                <text 
                  x={x} 
                  y={y} 
                  dy={16} 
                  textAnchor="end" 
                  fill={isTotal ? "#4f46e5" : "#64748b"} 
                  fontSize={11} 
                  fontWeight={isTotal ? "bold" : "normal"}
                  transform={`rotate(-25, ${x}, ${y})`}
                >
                  {payload.value}
                </text>
              );
            }}
            interval={0}
            height={60}
          />
          {/* Left Y-Axis for Rating */}
          <YAxis
            yAxisId="left"
            domain={[0, 5]}
            axisLine={false}
            tickLine={false}
            tick={{ fill: "#4f46e5", fontSize: 12, fontWeight: "bold" }}
            label={{ value: 'Estrellas', angle: -90, position: 'insideLeft', fill: '#4f46e5', fontSize: 12, offset: 10 }}
          />
          {/* Right Y-Axis for Votes */}
          <YAxis
            yAxisId="right"
            orientation="right"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "#94a3b8", fontSize: 12 }}
            label={{ value: 'Votos', angle: 90, position: 'insideRight', fill: '#94a3b8', fontSize: 12, offset: 10 }}
          />
          <Tooltip
            cursor={{ fill: "#f8fafc" }}
            contentStyle={{
              backgroundColor: "#fff",
              border: "1px solid #e2e8f0",
              borderRadius: "12px",
              boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)",
              padding: "12px"
            }}
          />
          <Legend verticalAlign="top" height={36}/>
          <Bar 
            yAxisId="left"
            dataKey="averageRating" 
            name="Promedio Estrellas" 
            radius={[4, 4, 0, 0]} 
            barSize={30} 
          >
            {chartData.map((entry: any, index) => (
              <Cell key={`cell-avg-${index}`} fill={entry.isTotal ? "#1e1b4b" : "#4f46e5"} />
            ))}
          </Bar>
          <Bar 
            yAxisId="right"
            dataKey="totalVotes" 
            name="Total Votos" 
            radius={[4, 4, 0, 0]} 
            barSize={30} 
          >
            {chartData.map((entry: any, index) => (
              <Cell key={`cell-votes-${index}`} fill={entry.isTotal ? "#475569" : "#94a3b8"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
